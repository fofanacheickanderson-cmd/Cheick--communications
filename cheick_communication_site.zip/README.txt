CHEICK COMMUNICATION — SITE WEB

1. Le fichier principal est index.html.
2. robots.txt et sitemap.xml servent au référencement.
3. Avant de publier sitemap.xml, remplacez VOTRE-URL par l'adresse réelle du site.
4. Ne mettez jamais de mot de passe, clé API ou information privée dans ce dossier.
